<template>
    <div>
        <a target="_blank" href="https://dedust.io/swap/TON/EQDf84FT8tdHZeI2-LXdb8gPMRqHRSABrmi8jI7MzvVpGJKZ">
            <button>
                Get OpenCoin
            </button>
        </a>
    </div>
</template>

<script>

</script>

<style scoped lang="scss">
    div {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: white;
        width: 100%;
        height: 100vh;
        a {
            button {
                font-family: 'Kanit', sans-serif;
                font-size: 30px; 
                font-weight: 700;
                padding: 20px;
                background-color: black;
                color: white;
                text-decoration: none;
                font-family: bold;
                min-width: 150px;
                border-radius: 15px;
                border: 1px solid transparent;
                margin-top: 20px;
                cursor: pointer;
            }
        }
        
    }
</style>